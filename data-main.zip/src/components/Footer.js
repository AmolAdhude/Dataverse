import React from "react";
import './footer.css'

const Footer = () => (
  <footer className="f-col">
    <p>
    © 2022 DataVerse. All Right Reserved.
    </p>
  </footer>
);

export default Footer;
